# Big 3 スタッツ表示の刷新

(内容は brain/implementation_plan.md と同一)
...
